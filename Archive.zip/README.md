# dji-emailtemplate-recreation
recreated dji email template
